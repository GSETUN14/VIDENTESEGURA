from flask import Flask, render_template, request, redirect, url_for, jsonify
import mysql.connector
from mysql.connector import Error

app = Flask(__name__, template_folder='Template', static_folder='static')

# Configuració de la base de dades
HOST = "localhost"
DATABASE = "llistatphpgst"
USER = "root"
PASSWORD = ""

# Connexió a la base de dades
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=HOST,
            database=DATABASE,
            user=USER,
            password=PASSWORD
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error al connectar-se: {e}")
        return None

# Crear un registre (Entrada o Sortida)
def crear_fitxatge(nom, tipus):
    try:
        connection = connect_to_database()
        if connection is not None:
            cursor = connection.cursor()
            cursor.execute(
                "INSERT INTO fitxatges (nom, tipus, hora) VALUES (%s, %s, NOW())",
                (nom, tipus)
            )
            connection.commit()
    except Error as e:
        print(f"Error al registrar el fitxatge: {e}")
    finally:
        if connection is not None and connection.is_connected():
            cursor.close()
            connection.close()

# Llegir els registres
def llegir_fitxatges():
    try:
        connection = connect_to_database()
        if connection is not None:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM fitxatges ORDER BY hora DESC")
            registres = cursor.fetchall()
            return registres
    except Error as e:
        print(f"Error al llegir els fitxatges: {e}")
        return []
    finally:
        if connection is not None and connection.is_connected():
            cursor.close()
            connection.close()

# Esborrar tots els registres
def esborrar_fitxatges():
    try:
        connection = connect_to_database()
        if connection is not None:
            cursor = connection.cursor()
            cursor.execute("DELETE FROM fitxatges")
            connection.commit()
    except Error as e:
        print(f"Error al esborrar els fitxatges: {e}")
    finally:
        if connection is not None and connection.is_connected():
            cursor.close()
            connection.close()

# Rutes del servidor
@app.route('/')
def index():
    fitxatges = llegir_fitxatges()
    return render_template('index.html', fitxatges=fitxatges)

@app.route('/fichar', methods=['POST'])
def fichar():
    nom = request.form['nom']
    if 'fichar_entrada' in request.form:
        crear_fitxatge(nom, 'Entrada')
    elif 'fichar_sortida' in request.form:
        crear_fitxatge(nom, 'Sortida')
    return redirect(url_for('index'))

@app.route('/borrar', methods=['POST'])
def borrar():
    esborrar_fitxatges()
    return redirect(url_for('index'))

# API per a JavaScript (opcional)
@app.route('/api/fitxatges', methods=['GET'])
def api_fitxatges():
    fitxatges = llegir_fitxatges()
    return jsonify(fitxatges)

if __name__ == "__main__":
    app.run(debug=True)
