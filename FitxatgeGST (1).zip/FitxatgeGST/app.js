document.addEventListener('DOMContentLoaded', function () {
    const apiUrl = '/api/fitxatges';
    const itemsList = document.getElementById('fitxatges-list');

    function fetchFitxatges() {
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                itemsList.innerHTML = '';
                data.forEach(fitxatge => {
                    const item = document.createElement('li');
                    item.textContent = `${fitxatge.nom} - ${fitxatge.tipus} - ${fitxatge.hora}`;
                    itemsList.appendChild(item);
                });
            })
            .catch(error => console.error('Error carregant els fitxatges:', error));
    }

    fetchFitxatges();
});